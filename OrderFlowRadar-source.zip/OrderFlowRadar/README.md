# OrderFlow Radar — Android

Binance USDⓈ-M Futures için **salt-okunur (read-only)** canlı piyasa izleme uygulaması.
Emir göndermez, API key istemez ve yalnızca public market verisini kullanır.

## Özellikler

- Kullanıcının kendi coin izleme listesi; `BTC`, `DOGE` gibi girişlarda otomatik `USDT` ekleme
- Coin seçildiğinde ayrı, tam ekran **landscape** izleme paneli
- 1 dakikalık canlı mum + 120 mum REST geçmişi
- Binance'ın 2026 USDⓈ-M WebSocket mimarisine göre bağlantılar:
  - high-frequency order book: `wss://fstream.binance.com/public/...`
  - regular market streams: `wss://fstream.binance.com/market/...`
- REST snapshot + `@depth@100ms` diff akışıyla lokal order book
- ±1% fiyat bandında mesafe-ağırlıklı Order Book Imbalance
- Order-book liquidity heatmap; **gelecekteki liquidation map değildir**
- Aggressive Buy/Sell Delta (`aggTrade`)
- 5 dakikalık rolling CVD bağlamı
- Absorption skoru
- Liquidity Add / Pull skoru; yalnızca yakın ±1% book değişimleri skora girer
- Gerçekleşen long/short liquidation notional (`forceOrder`)
- Mark price + funding rate
- 5s / 15s / 30s / 1m / 5m hesap pencereleri
- Ağırlıklı Market Pressure skoru (-100…+100)
- Her metrik için sabit renk; **yoğunluk ve çubuk uzunluğu baskınlığı** gösterir
- Coin listesi cihazda kalıcı saklanır

## Renkler

- Order Book: mavi
- Aggressive Delta: yeşil
- Rolling CVD: mor
- Absorption: amber/sarı
- Liquidity Add/Pull: cyan
- Liquidations: turuncu
- Genel yön göstergesi: pozitif yeşil / negatif kırmızı

## Derleme

### Android Studio

1. Bu klasörü Android Studio ile açın.
2. JDK olarak **17** seçin.
3. Android SDK **35** yüklü olsun.
4. Proje Gradle sürümü olarak **8.9** kullanın (AGP 8.7.x için minimum 8.9).
5. Gradle Sync tamamlanınca `app` modülünü çalıştırın veya **Build > Build APK(s)** seçin.

Bağımlılık:

```text
com.squareup.okhttp3:okhttp:5.3.2
```

Komut satırında Gradle 8.9 kuruluysa:

```bash
gradle :app:assembleDebug
```

Normal debug çıktısı:

```text
app/build/outputs/apk/debug/app-debug.apk
```

> Bu teslim paketinde Gradle Wrapper binary'si bulunmuyor. Android Studio veya sistemde kurulu Gradle 8.9 ile açılabilir.

## Veri ve hesap mantığı

### Order Book senkronizasyonu

Uygulama önce:

```text
GET https://fapi.binance.com/fapi/v1/depth?symbol=BTCUSDT&limit=1000
```

snapshot'ını alır. Bu sırada `@depth@100ms` olaylarını tamponlar. Snapshot'tan sonra update ID zinciri uygulanır. `pu` / update-ID zincirinde boşluk görülürse lokal book güvenilmez kabul edilir ve snapshot yeniden alınır.

### Mesafe ağırlığı

Hem imbalance hem yakın book-flow hesabında:

- ≤0.10% → 1.00
- ≤0.25% → 0.80
- ≤0.50% → 0.50
- ≤1.00% → 0.25
- >1.00% → flow skoruna dahil edilmez

Böylece uzakta duran dev bir emir, fiyatın hemen yanındaki likiditeyi yapay biçimde bastırmaz.

### Aggressive Delta

`aggTrade` içindeki maker alanı kullanılır:

- `m=false` → agresif market buy → pozitif
- `m=true` → agresif market sell → negatif

Notional yaklaşık olarak `price × quantity` ile hesaplanır.

### Liquidity Add / Pull

- Bid eklenmesi → bullish
- Bid kaldırılması → bearish
- Ask eklenmesi → bearish
- Ask kaldırılması → bullish

Bu akışın pressure metriğinde yalnızca fiyatın ±1% çevresindeki değişiklikler kullanılır.

### Absorption

Taker akışı belirgin biçimde tek tarafa yığılırken fiyatın aynı ölçüde ilerleyememesi, karşı tarafın absorpsiyonu olarak skorlanır. Bu **heuristic** bir göstergedir; kesin spoofing veya kesin yön sinyali değildir.

### Liquidations

`forceOrder` stream yalnızca **gerçekleşen liquidation olaylarını** toplar. Order-book heatmap ile liquidation verisi ayrı tutulur.

### Market Pressure

V1 ağırlıkları:

- Order Book: 30%
- Aggressive Delta: 25%
- Rolling CVD: 12%
- Liquidity Add/Pull: 18%
- Absorption: 10%
- Liquidations: 5%

Bu skor **BUY/SELL emri veya yatırım sinyali değildir**; o anki piyasa mikro-yapısı baskısını tek değerde özetler.

## Kaynak dosyalar

- `MainActivity.java` — coin listesi
- `MarketActivity.java` — tam ekran monitor
- `MarketCanvasView.java` — mum, heatmap ve metrik çizimleri
- `BinanceMarketClient.java` — REST + WebSocket bağlantıları
- `OrderBook.java` — lokal book, imbalance, wall ve liquidity-flow hesabı
- `MarketState.java` — rolling metrikler ve composite pressure
- `CoinStore.java` — izleme listesinin kalıcı saklanması
- `Ui.java` — ortak renk/ölçü yardımcıları

## Doğrulama

Bu çalışma ortamında gerçek Android SDK / AAPT2 / D8 / Gradle toolchain bulunmadığı için burada imzalı APK binary'si üretilemedi. Buna karşılık:

- Tüm Java kaynakları Android, JSON ve OkHttp API imzalarını taklit eden yerel stub'larla `javac` üzerinden derlendi: **başarılı**.
- Order-book yakınlık ağırlığı, update zinciri/gap tespiti, delta, rolling CVD, liquidity flow, liquidation pressure, composite pressure ve absorption için yerel mantık testleri çalıştırıldı: **başarılı**.
- Gerçek cihaz / emülatör ve canlı Binance ağı üzerinde runtime testi bu ortamda yapılamadı.

Ayrıntı için `BUILD_STATUS.txt` dosyasına bakın.

## Güvenlik / kullanım notu

Bu sürüm yalnızca public Binance verisini okur. API key, secret, kullanıcı hesabı veya trade izni içermez. Market data gecikebilir, eksik olabilir veya bağlantı kesilebilir; finansal kararların tek kaynağı olarak kullanılmamalıdır.

## GitHub Actions ile telefondan APK

Bilgisayarın yoksa `.github/workflows/build-apk.yml` GitHub üzerinde otomatik debug APK üretir. Telefon için ayrıntılı adımlar `TELEFONDAN_KURULUM.md` dosyasındadır.
