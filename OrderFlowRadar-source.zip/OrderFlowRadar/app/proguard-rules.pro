# No custom shrinking rules required for v1.
