package com.oktay.orderflowradar;

import android.os.Handler;
import android.os.Looper;

import org.json.JSONArray;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Locale;
import java.util.concurrent.TimeUnit;
import java.util.concurrent.atomic.AtomicBoolean;

import okhttp3.Call;
import okhttp3.Callback;
import okhttp3.OkHttpClient;
import okhttp3.Request;
import okhttp3.Response;
import okhttp3.WebSocket;
import okhttp3.WebSocketListener;

final class BinanceMarketClient {
    interface Listener {
        void onStateChanged();
    }

    private static final String REST = "https://fapi.binance.com";
    private static final String PUBLIC_WS = "wss://fstream.binance.com/public/ws/";
    private static final String MARKET_WS = "wss://fstream.binance.com/market/stream?streams=";

    private final String symbol;
    private final String lowerSymbol;
    private final MarketState state;
    private final Listener listener;
    private final Handler main = new Handler(Looper.getMainLooper());
    private final OkHttpClient http;
    private final Object depthLock = new Object();
    private final List<JSONObject> depthBuffer = new ArrayList<>();
    private final AtomicBoolean reconnectScheduled = new AtomicBoolean(false);

    private volatile WebSocket depthSocket;
    private volatile WebSocket marketSocket;
    private volatile boolean stopped;
    private volatile int generation;
    private boolean snapshotReady;
    private boolean snapshotInFlight;

    BinanceMarketClient(String symbol, MarketState state, Listener listener) {
        this.symbol = symbol.toUpperCase(Locale.US);
        this.lowerSymbol = this.symbol.toLowerCase(Locale.US);
        this.state = state;
        this.listener = listener;
        this.http = new OkHttpClient.Builder()
                .connectTimeout(10, TimeUnit.SECONDS)
                .readTimeout(15, TimeUnit.SECONDS)
                .writeTimeout(15, TimeUnit.SECONDS)
                .retryOnConnectionFailure(true)
                .build();
    }

    void start() {
        stopped = false;
        connectAll();
    }

    void stop() {
        stopped = true;
        generation++;
        reconnectScheduled.set(false);
        WebSocket d = depthSocket;
        WebSocket m = marketSocket;
        depthSocket = null;
        marketSocket = null;
        if (d != null) d.close(1000, "screen closed");
        if (m != null) m.close(1000, "screen closed");
        http.dispatcher().cancelAll();
    }

    private void connectAll() {
        if (stopped) return;
        int gen = ++generation;
        reconnectScheduled.set(false);
        state.clearError();
        state.setStatus("BAĞLANIYOR");
        state.setBookReady(false);
        notifyChanged();

        synchronized (depthLock) {
            depthBuffer.clear();
            snapshotReady = false;
            snapshotInFlight = false;
            state.orderBook.reset();
        }

        connectDepth(gen);
        connectMarket(gen);
        loadKlines(gen);
    }

    private void connectDepth(int gen) {
        Request request = new Request.Builder()
                .url(PUBLIC_WS + lowerSymbol + "@depth@100ms")
                .build();
        depthSocket = http.newWebSocket(request, new WebSocketListener() {
            @Override public void onOpen(WebSocket webSocket, Response response) {
                if (!isCurrent(gen)) return;
                state.setStatus("BOOK SENKRONİZE EDİLİYOR");
                notifyChanged();
                requestDepthSnapshot(gen);
            }

            @Override public void onMessage(WebSocket webSocket, String text) {
                if (!isCurrent(gen)) return;
                try {
                    JSONObject e = new JSONObject(text);
                    if (!"depthUpdate".equals(e.optString("e"))) return;
                    int st = e.optInt("st", 1);
                    if (st != 1) return;
                    handleDepthEvent(gen, e);
                } catch (Exception ignored) {
                }
            }

            @Override public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                if (!isCurrent(gen)) return;
                scheduleReconnect("Depth bağlantısı koptu");
            }

            @Override public void onClosed(WebSocket webSocket, int code, String reason) {
                if (isCurrent(gen) && !stopped) scheduleReconnect("Depth bağlantısı kapandı");
            }
        });
    }

    private void connectMarket(int gen) {
        String streams = lowerSymbol + "@aggTrade/" +
                lowerSymbol + "@kline_1m/" +
                lowerSymbol + "@forceOrder/" +
                lowerSymbol + "@markPrice@1s";
        Request request = new Request.Builder().url(MARKET_WS + streams).build();
        marketSocket = http.newWebSocket(request, new WebSocketListener() {
            @Override public void onOpen(WebSocket webSocket, Response response) {
                if (!isCurrent(gen)) return;
                state.setStatus("MARKET CANLI");
                notifyChanged();
            }

            @Override public void onMessage(WebSocket webSocket, String text) {
                if (!isCurrent(gen)) return;
                try {
                    JSONObject root = new JSONObject(text);
                    JSONObject e = root.optJSONObject("data");
                    if (e == null) e = root;
                    int st = e.optInt("st", 1);
                    if (st != 1) return;
                    handleMarketEvent(e);
                } catch (Exception ignored) {
                }
            }

            @Override public void onFailure(WebSocket webSocket, Throwable t, Response response) {
                if (!isCurrent(gen)) return;
                scheduleReconnect("Market bağlantısı koptu");
            }

            @Override public void onClosed(WebSocket webSocket, int code, String reason) {
                if (isCurrent(gen) && !stopped) scheduleReconnect("Market bağlantısı kapandı");
            }
        });
    }

    private void handleMarketEvent(JSONObject e) {
        String type = e.optString("e", "");
        switch (type) {
            case "aggTrade": {
                long time = e.optLong("T", e.optLong("E", System.currentTimeMillis()));
                double p = num(e, "p");
                double q = num(e, "q");
                boolean maker = e.optBoolean("m", false);
                state.addTrade(time, p, q, maker);
                break;
            }
            case "kline": {
                JSONObject k = e.optJSONObject("k");
                if (k != null) {
                    MarketState.Candle c = new MarketState.Candle(
                            k.optLong("t"), num(k, "o"), num(k, "h"), num(k, "l"),
                            num(k, "c"), num(k, "v"), k.optBoolean("x", false));
                    state.updateCandle(c);
                }
                break;
            }
            case "forceOrder": {
                JSONObject o = e.optJSONObject("o");
                if (o != null) {
                    long time = o.optLong("T", e.optLong("E", System.currentTimeMillis()));
                    boolean longLiq = "SELL".equalsIgnoreCase(o.optString("S"));
                    double price = num(o, "ap");
                    if (price <= 0) price = num(o, "p");
                    double qty = num(o, "z");
                    if (qty <= 0) qty = num(o, "q");
                    state.addLiquidation(time, longLiq, price * qty);
                }
                break;
            }
            case "markPriceUpdate": {
                state.updateMark(num(e, "p"), num(e, "r"));
                break;
            }
            default:
                break;
        }
        notifyChanged();
    }

    private void handleDepthEvent(int gen, JSONObject e) {
        synchronized (depthLock) {
            if (!snapshotReady) {
                depthBuffer.add(e);
                if (depthBuffer.size() > 4000) {
                    scheduleReconnect("Order book tamponu taştı");
                }
                return;
            }
            OrderBook.ApplyResult r = state.orderBook.applyDepth(e);
            if (r.result == OrderBook.Result.GAP) {
                snapshotReady = false;
                state.setBookReady(false);
                depthBuffer.clear();
                depthBuffer.add(e);
                requestDepthSnapshot(gen);
                notifyChanged();
                return;
            }
            if (r.result == OrderBook.Result.APPLIED) {
                state.addBookFlow(e.optLong("E", System.currentTimeMillis()),
                        r.pressureNotional, r.changedNotional);
                state.setBookReady(true);
                notifyChanged();
            }
        }
    }

    private void requestDepthSnapshot(int gen) {
        synchronized (depthLock) {
            if (snapshotInFlight || stopped || gen != generation) return;
            snapshotInFlight = true;
        }
        String url = REST + "/fapi/v1/depth?symbol=" + symbol + "&limit=1000";
        http.newCall(new Request.Builder().url(url).build()).enqueue(new Callback() {
            @Override public void onFailure(Call call, IOException e) {
                synchronized (depthLock) { snapshotInFlight = false; }
                if (isCurrent(gen)) scheduleReconnect("Order book snapshot alınamadı");
            }

            @Override public void onResponse(Call call, Response response) throws IOException {
                String body = response.body() == null ? "" : response.body().string();
                if (!isCurrent(gen)) return;
                if (!response.isSuccessful()) {
                    synchronized (depthLock) { snapshotInFlight = false; }
                    scheduleReconnect("Snapshot HTTP " + response.code());
                    return;
                }
                try {
                    JSONObject json = new JSONObject(body);
                    long lastUpdateId = json.optLong("lastUpdateId", -1);
                    JSONArray bids = json.optJSONArray("bids");
                    JSONArray asks = json.optJSONArray("asks");
                    if (lastUpdateId < 0 || bids == null || asks == null) throw new IllegalStateException("snapshot");
                    applySnapshot(gen, lastUpdateId, bids, asks);
                } catch (Exception ex) {
                    synchronized (depthLock) { snapshotInFlight = false; }
                    scheduleReconnect("Snapshot çözümlenemedi");
                }
            }
        });
    }

    private void applySnapshot(int gen, long updateId, JSONArray bids, JSONArray asks) {
        boolean gap = false;
        synchronized (depthLock) {
            if (!isCurrent(gen)) return;
            snapshotInFlight = false;
            state.orderBook.setSnapshot(updateId, bids, asks);

            for (JSONObject e : depthBuffer) {
                OrderBook.ApplyResult r = state.orderBook.applyDepth(e);
                if (r.result == OrderBook.Result.GAP) {
                    gap = true;
                    break;
                }
                if (r.result == OrderBook.Result.APPLIED) {
                    state.addBookFlow(e.optLong("E", System.currentTimeMillis()),
                            r.pressureNotional, r.changedNotional);
                }
            }
            if (!gap) {
                depthBuffer.clear();
                snapshotReady = true;
                state.setBookReady(true);
            } else {
                snapshotReady = false;
                state.setBookReady(false);
                // Keep only future events from now on; a fresh snapshot will anchor them.
                depthBuffer.clear();
            }
        }
        notifyChanged();
        if (gap) requestDepthSnapshot(gen);
    }

    private void loadKlines(int gen) {
        String url = REST + "/fapi/v1/klines?symbol=" + symbol + "&interval=1m&limit=120";
        http.newCall(new Request.Builder().url(url).build()).enqueue(new Callback() {
            @Override public void onFailure(Call call, IOException e) {
                // WebSocket can still operate without history. Do not tear down the whole session.
            }

            @Override public void onResponse(Call call, Response response) throws IOException {
                String body = response.body() == null ? "" : response.body().string();
                if (!isCurrent(gen) || !response.isSuccessful()) return;
                try {
                    JSONArray rows = new JSONArray(body);
                    List<MarketState.Candle> seed = new ArrayList<>();
                    for (int i = 0; i < rows.length(); i++) {
                        JSONArray r = rows.optJSONArray(i);
                        if (r == null || r.length() < 7) continue;
                        seed.add(new MarketState.Candle(
                                r.optLong(0), r.optDouble(1), r.optDouble(2), r.optDouble(3),
                                r.optDouble(4), r.optDouble(5), r.optLong(6) < System.currentTimeMillis()));
                    }
                    state.seedCandles(seed);
                    notifyChanged();
                } catch (Exception ignored) {
                }
            }
        });
    }

    private void scheduleReconnect(String reason) {
        if (stopped) return;
        state.setError(reason);
        state.setStatus("YENİDEN BAĞLANIYOR");
        notifyChanged();
        if (!reconnectScheduled.compareAndSet(false, true)) return;
        final int expectedGen = generation;
        main.postDelayed(() -> {
            if (stopped || expectedGen != generation) return;
            WebSocket d = depthSocket;
            WebSocket m = marketSocket;
            if (d != null) d.cancel();
            if (m != null) m.cancel();
            connectAll();
        }, 1600);
    }

    private boolean isCurrent(int gen) {
        return !stopped && gen == generation;
    }

    private void notifyChanged() {
        if (listener != null) listener.onStateChanged();
    }

    private static double num(JSONObject o, String key) {
        Object v = o.opt(key);
        if (v instanceof Number) return ((Number) v).doubleValue();
        if (v == null) return 0;
        try { return Double.parseDouble(String.valueOf(v)); }
        catch (Exception e) { return 0; }
    }
}
