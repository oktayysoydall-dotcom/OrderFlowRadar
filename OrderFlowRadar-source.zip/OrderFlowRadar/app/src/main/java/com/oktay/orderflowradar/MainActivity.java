package com.oktay.orderflowradar;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.Intent;
import android.graphics.Color;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;

import java.util.List;

public class MainActivity extends Activity {
    private LinearLayout coinList;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        buildUi();
    }

    @Override
    protected void onResume() {
        super.onResume();
        refreshCoins();
    }

    private void buildUi() {
        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setBackgroundColor(Ui.BG);
        Ui.pad(root, this, 18, 18, 18, 18);

        TextView title = new TextView(this);
        title.setText("ORDERFLOW RADAR");
        Ui.styleText(title, 24, Ui.TEXT, true);
        root.addView(title);

        TextView subtitle = new TextView(this);
        subtitle.setText("Binance USDⓈ-M Futures • İzleme terminali • İşlem açmaz");
        Ui.styleText(subtitle, 12, Ui.MUTED, false);
        subtitle.setPadding(0, Ui.dp(this, 4), 0, Ui.dp(this, 16));
        root.addView(subtitle);

        LinearLayout addBox = new LinearLayout(this);
        addBox.setOrientation(LinearLayout.HORIZONTAL);
        addBox.setGravity(Gravity.CENTER_VERTICAL);
        addBox.setBackground(Ui.roundedStroke(Ui.PANEL, Ui.BORDER, 12, this));
        Ui.pad(addBox, this, 10, 8, 8, 8);

        EditText input = new EditText(this);
        input.setSingleLine(true);
        input.setHint("BTC, DOGE veya BTCUSDT");
        input.setHintTextColor(Ui.MUTED);
        input.setTextColor(Ui.TEXT);
        input.setBackgroundColor(Color.TRANSPARENT);
        input.setTextSize(15);
        LinearLayout.LayoutParams inputLp = new LinearLayout.LayoutParams(0, Ui.dp(this, 48), 1f);
        addBox.addView(input, inputLp);

        Button add = new Button(this);
        add.setText("EKLE");
        add.setTextColor(Ui.BG);
        add.setTextSize(13);
        add.setAllCaps(false);
        add.setBackground(Ui.rounded(Ui.CYAN, 9, this));
        LinearLayout.LayoutParams addLp = new LinearLayout.LayoutParams(Ui.dp(this, 82), Ui.dp(this, 42));
        addLp.setMargins(Ui.dp(this, 8), 0, 0, 0);
        addBox.addView(add, addLp);
        root.addView(addBox);

        TextView hint = new TextView(this);
        hint.setText("Bir coine dokununca tam ekran yatay izleme paneli açılır. Uzun basarak listeden silebilirsin.");
        Ui.styleText(hint, 12, Ui.MUTED, false);
        hint.setPadding(0, Ui.dp(this, 12), 0, Ui.dp(this, 12));
        root.addView(hint);

        ScrollView scroll = new ScrollView(this);
        coinList = new LinearLayout(this);
        coinList.setOrientation(LinearLayout.VERTICAL);
        scroll.addView(coinList, new ScrollView.LayoutParams(
                ScrollView.LayoutParams.MATCH_PARENT, ScrollView.LayoutParams.WRAP_CONTENT));
        root.addView(scroll, new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, 0, 1f));

        TextView footer = new TextView(this);
        footer.setText("Not: Heatmap, public order-book likiditesini gösterir; gelecekteki tasfiye seviyeleri değildir.");
        Ui.styleText(footer, 11, Ui.MUTED, false);
        footer.setPadding(0, Ui.dp(this, 12), 0, 0);
        root.addView(footer);

        add.setOnClickListener(v -> {
            String symbol = CoinStore.normalize(input.getText().toString());
            if (symbol.isEmpty()) {
                Toast.makeText(this, "Geçerli bir sembol yaz.", Toast.LENGTH_SHORT).show();
                return;
            }
            CoinStore.add(this, symbol);
            input.setText("");
            refreshCoins();
        });

        input.setOnEditorActionListener((v, actionId, event) -> {
            add.performClick();
            return true;
        });

        setContentView(root);
    }

    private void refreshCoins() {
        if (coinList == null) return;
        coinList.removeAllViews();
        List<String> symbols = CoinStore.load(this);
        for (String symbol : symbols) {
            coinList.addView(makeCoinRow(symbol));
        }
    }

    private View makeCoinRow(String symbol) {
        LinearLayout row = new LinearLayout(this);
        row.setOrientation(LinearLayout.HORIZONTAL);
        row.setGravity(Gravity.CENTER_VERTICAL);
        row.setBackground(Ui.roundedStroke(Ui.PANEL, Ui.BORDER, 12, this));
        Ui.pad(row, this, 16, 13, 14, 13);
        LinearLayout.LayoutParams rowLp = new LinearLayout.LayoutParams(
                LinearLayout.LayoutParams.MATCH_PARENT, LinearLayout.LayoutParams.WRAP_CONTENT);
        rowLp.setMargins(0, 0, 0, Ui.dp(this, 9));
        row.setLayoutParams(rowLp);

        LinearLayout texts = new LinearLayout(this);
        texts.setOrientation(LinearLayout.VERTICAL);
        TextView name = new TextView(this);
        name.setText(symbol);
        Ui.styleText(name, 18, Ui.TEXT, true);
        texts.addView(name);
        TextView desc = new TextView(this);
        desc.setText("Order book • Delta • CVD • Absorption • Liquidations");
        Ui.styleText(desc, 11, Ui.MUTED, false);
        texts.addView(desc);
        row.addView(texts, new LinearLayout.LayoutParams(0, LinearLayout.LayoutParams.WRAP_CONTENT, 1f));

        TextView arrow = new TextView(this);
        arrow.setText("›");
        Ui.styleText(arrow, 30, Ui.CYAN, false);
        arrow.setGravity(Gravity.CENTER);
        row.addView(arrow, new LinearLayout.LayoutParams(Ui.dp(this, 36), Ui.dp(this, 44)));

        row.setOnClickListener(v -> {
            Intent i = new Intent(this, MarketActivity.class);
            i.putExtra(MarketActivity.EXTRA_SYMBOL, symbol);
            startActivity(i);
        });

        row.setOnLongClickListener(v -> {
            new AlertDialog.Builder(this)
                    .setTitle(symbol + " silinsin mi?")
                    .setMessage("Sadece izleme listesinden kaldırılır.")
                    .setNegativeButton("Vazgeç", null)
                    .setPositiveButton("Sil", (d, which) -> {
                        CoinStore.remove(this, symbol);
                        refreshCoins();
                    })
                    .show();
            return true;
        });
        return row;
    }
}
