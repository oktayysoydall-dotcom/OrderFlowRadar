package com.oktay.orderflowradar;

import android.content.Context;
import android.graphics.Canvas;
import android.graphics.Color;
import android.graphics.Paint;
import android.graphics.Path;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.view.MotionEvent;
import android.view.View;

import java.util.ArrayList;
import java.util.List;
import java.util.Locale;

final class MarketCanvasView extends View {
    private final MarketState state;
    private final Paint p = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final Paint stroke = new Paint(Paint.ANTI_ALIAS_FLAG);
    private final long[] windows = {5_000L, 15_000L, 30_000L, 60_000L, 300_000L};
    private final String[] windowLabels = {"5s", "15s", "30s", "1m", "5m"};
    private final List<RectF> windowRects = new ArrayList<>();
    private final RectF closeRect = new RectF();
    private int selectedWindow = 2;
    private Runnable onClose;

    MarketCanvasView(Context context, MarketState state) {
        super(context);
        this.state = state;
        setBackgroundColor(Ui.BG);
        p.setTypeface(Typeface.create(Typeface.SANS_SERIF, Typeface.NORMAL));
        stroke.setStyle(Paint.Style.STROKE);
        stroke.setStrokeWidth(dp(1));
        stroke.setColor(Ui.BORDER);
        setLayerType(View.LAYER_TYPE_SOFTWARE, null);
    }

    void setOnClose(Runnable onClose) {
        this.onClose = onClose;
    }

    @Override
    protected void onDraw(Canvas c) {
        super.onDraw(c);
        MarketState.Snapshot s = state.snapshot(windows[selectedWindow]);
        float w = getWidth();
        float h = getHeight();
        if (w <= 0 || h <= 0) return;

        float pad = dp(14);
        float top = dp(12);
        float headerH = dp(54);
        float gap = dp(10);
        float rightW = Math.max(dp(300), w * 0.31f);
        float chartRight = w - rightW - gap - pad;
        RectF chart = new RectF(pad, top + headerH, chartRight, h - pad);
        RectF right = new RectF(chartRight + gap, top + headerH, w - pad, h - pad);

        drawHeader(c, s, pad, top, chartRight, w - pad);
        drawChart(c, s, chart);
        drawRightPanel(c, s, right);
    }

    private void drawHeader(Canvas c, MarketState.Snapshot s, float left, float top,
                            float chartRight, float right) {
        closeRect.set(left, top, left + dp(38), top + dp(38));
        roundRect(c, closeRect, Ui.PANEL, dp(9));
        text(c, "‹", closeRect.centerX(), closeRect.centerY() + dp(8), dp(30), Ui.TEXT,
                Paint.Align.CENTER, true);

        float x = closeRect.right + dp(12);
        text(c, s.symbol, x, top + dp(23), dp(20), Ui.TEXT, Paint.Align.LEFT, true);
        text(c, formatPrice(s.lastPrice), x, top + dp(45), dp(14), Ui.CYAN, Paint.Align.LEFT, true);

        float infoX = x + dp(155);
        text(c, "MARK " + formatPrice(s.markPrice), infoX, top + dp(19), dp(11), Ui.MUTED, Paint.Align.LEFT, false);
        text(c, "FUND " + formatPercent(s.fundingRate * 100.0, 4), infoX, top + dp(40), dp(11), Ui.MUTED, Paint.Align.LEFT, false);

        windowRects.clear();
        float bx = Math.max(infoX + dp(150), chartRight - dp(230));
        for (int i = 0; i < windowLabels.length; i++) {
            RectF r = new RectF(bx + i * dp(45), top + dp(6), bx + i * dp(45) + dp(39), top + dp(38));
            windowRects.add(r);
            int bg = i == selectedWindow ? Color.rgb(31, 50, 64) : Ui.PANEL;
            int border = i == selectedWindow ? Ui.CYAN : Ui.BORDER;
            roundRect(c, r, bg, dp(7));
            p.setStyle(Paint.Style.STROKE);
            p.setStrokeWidth(dp(1));
            p.setColor(border);
            c.drawRoundRect(r, dp(7), dp(7), p);
            p.setStyle(Paint.Style.FILL);
            text(c, windowLabels[i], r.centerX(), r.centerY() + dp(4), dp(11),
                    i == selectedWindow ? Ui.TEXT : Ui.MUTED, Paint.Align.CENTER, i == selectedWindow);
        }

        int statusColor = "CANLI".equals(s.status) ? Ui.GREEN : ("HATA".equals(s.status) ? Ui.RED : Ui.AMBER);
        float statusX = right - dp(115);
        p.setColor(statusColor);
        c.drawCircle(statusX, top + dp(22), dp(4), p);
        text(c, s.status, statusX + dp(10), top + dp(26), dp(10), Ui.MUTED, Paint.Align.LEFT, true);
    }

    private void drawChart(Canvas c, MarketState.Snapshot s, RectF r) {
        roundRect(c, r, Ui.PANEL, dp(12));
        RectF plot = new RectF(r.left + dp(10), r.top + dp(26), r.right - dp(56), r.bottom - dp(26));

        text(c, "1m CANLI MUM  •  ORDER-BOOK LIQUIDITY HEATMAP", r.left + dp(12), r.top + dp(17),
                dp(10), Ui.MUTED, Paint.Align.LEFT, true);

        List<MarketState.Candle> candles = s.candles;
        if (candles.size() < 2) {
            text(c, "Mum geçmişi yükleniyor…", r.centerX(), r.centerY(), dp(14), Ui.MUTED, Paint.Align.CENTER, false);
            return;
        }

        int count = Math.min(64, candles.size());
        int start = candles.size() - count;
        double min = Double.MAX_VALUE;
        double max = -Double.MAX_VALUE;
        for (int i = start; i < candles.size(); i++) {
            MarketState.Candle k = candles.get(i);
            min = Math.min(min, k.low);
            max = Math.max(max, k.high);
        }
        if (s.lastPrice > 0) {
            min = Math.min(min, s.lastPrice * 0.9975);
            max = Math.max(max, s.lastPrice * 1.0025);
        }
        double range = max - min;
        if (range <= 0) range = Math.max(1e-8, max * 0.001);
        min -= range * 0.06;
        max += range * 0.06;

        drawGrid(c, plot, min, max);
        drawHeatmap(c, s.walls, plot, min, max);

        float slot = plot.width() / count;
        float bodyW = Math.max(dp(2), slot * 0.58f);
        for (int i = 0; i < count; i++) {
            MarketState.Candle k = candles.get(start + i);
            float cx = plot.left + slot * (i + 0.5f);
            float yH = yFor(k.high, plot, min, max);
            float yL = yFor(k.low, plot, min, max);
            float yO = yFor(k.open, plot, min, max);
            float yC = yFor(k.close, plot, min, max);
            int color = k.close >= k.open ? Ui.GREEN : Ui.RED;
            p.setColor(withAlpha(color, 220));
            p.setStrokeWidth(Math.max(dp(1), slot * 0.10f));
            c.drawLine(cx, yH, cx, yL, p);
            float t = Math.min(yO, yC);
            float b = Math.max(yO, yC);
            if (b - t < dp(1.5f)) b = t + dp(1.5f);
            p.setColor(color);
            c.drawRect(cx - bodyW / 2, t, cx + bodyW / 2, b, p);
        }

        if (s.lastPrice > 0) {
            float py = yFor(s.lastPrice, plot, min, max);
            p.setColor(withAlpha(Ui.TEXT, 150));
            p.setStrokeWidth(dp(1));
            c.drawLine(plot.left, py, plot.right, py, p);
            RectF tag = new RectF(plot.right + dp(3), py - dp(10), r.right - dp(6), py + dp(10));
            roundRect(c, tag, Color.rgb(37, 46, 56), dp(5));
            text(c, formatPrice(s.lastPrice), tag.centerX(), tag.centerY() + dp(4), dp(9), Ui.TEXT,
                    Paint.Align.CENTER, true);
        }

        String note = s.bookReady
                ? "Heatmap: mevcut order-book yoğunluğu • parlaklık = göreli büyüklük"
                : "Order book senkronize ediliyor…";
        text(c, note, r.left + dp(12), r.bottom - dp(8), dp(9), Ui.MUTED, Paint.Align.LEFT, false);
    }

    private void drawGrid(Canvas c, RectF plot, double min, double max) {
        p.setStrokeWidth(dp(1));
        for (int i = 0; i <= 4; i++) {
            float y = plot.top + plot.height() * i / 4f;
            p.setColor(Color.rgb(24, 32, 42));
            c.drawLine(plot.left, y, plot.right, y, p);
            double price = max - (max - min) * i / 4.0;
            text(c, formatPrice(price), plot.right + dp(4), y + dp(3), dp(8), Ui.MUTED, Paint.Align.LEFT, false);
        }
        for (int i = 0; i <= 6; i++) {
            float x = plot.left + plot.width() * i / 6f;
            p.setColor(Color.rgb(18, 25, 34));
            c.drawLine(x, plot.top, x, plot.bottom, p);
        }
    }

    private void drawHeatmap(Canvas c, List<OrderBook.Wall> walls, RectF plot, double min, double max) {
        if (walls == null || walls.isEmpty()) return;
        double biggest = 0;
        for (OrderBook.Wall w : walls) biggest = Math.max(biggest, w.notional);
        if (biggest <= 0) return;
        for (OrderBook.Wall wall : walls) {
            if (wall.price < min || wall.price > max) continue;
            double strength = Math.sqrt(wall.notional / biggest);
            int alpha = (int) (22 + 120 * strength);
            float y = yFor(wall.price, plot, min, max);
            float bandH = Math.max(dp(2), dp(3.2f) * (float) strength);
            float width = plot.width() * (0.22f + 0.70f * (float) strength);
            p.setColor(withAlpha(Ui.BLUE, alpha));
            c.drawRect(plot.right - width, y - bandH, plot.right, y + bandH, p);
        }
    }

    private void drawRightPanel(Canvas c, MarketState.Snapshot s, RectF r) {
        float pressureH = Math.min(dp(116), r.height() * 0.18f);
        RectF pressure = new RectF(r.left, r.top, r.right, r.top + pressureH);
        roundRect(c, pressure, Ui.PANEL, dp(12));
        drawPressure(c, s, pressure);

        float gap = dp(7);
        float startY = pressure.bottom + gap;
        float available = r.bottom - startY;
        float cardH = (available - gap * 5) / 6f;

        metricCard(c, rect(r.left, startY + (cardH + gap) * 0, r.right, cardH),
                "ORDER BOOK", s.bookImbalance, Ui.BLUE,
                s.bookImbalance >= 0 ? "BID BASKIN" : "ASK BASKIN",
                "±1% ağırlıklı derinlik");

        metricCard(c, rect(r.left, startY + (cardH + gap) * 1, r.right, cardH),
                "AGGRESSIVE DELTA", s.deltaRatio, Ui.GREEN,
                s.deltaRatio >= 0 ? "MARKET BUY" : "MARKET SELL",
                signedMoney(s.deltaNotional) + "  •  " + windowLabel());

        metricCard(c, rect(r.left, startY + (cardH + gap) * 2, r.right, cardH),
                "ROLLING CVD", s.cvdRatio, Ui.PURPLE,
                s.cvdRatio >= 0 ? "BUY FLOW" : "SELL FLOW",
                signedMoney(s.cvdNotional) + "  •  bağlam ≤5m");

        metricCard(c, rect(r.left, startY + (cardH + gap) * 3, r.right, cardH),
                "ABSORPTION", s.absorption, Ui.AMBER,
                s.absorption > 8 ? "BUY ABSORPTION" : (s.absorption < -8 ? "SELL ABSORPTION" : "DÜŞÜK"),
                String.format(Locale.US, "fiyat %.1f bps", s.priceChangeBps));

        metricCard(c, rect(r.left, startY + (cardH + gap) * 4, r.right, cardH),
                "LIQUIDITY ADD / PULL", s.liquidityFlow, Ui.CYAN,
                s.liquidityFlow >= 0 ? "BULLISH FLOW" : "BEARISH FLOW",
                "eklenen/kaldırılan book likiditesi");

        metricCard(c, rect(r.left, startY + (cardH + gap) * 5, r.right, cardH),
                "LIQUIDATIONS", s.liquidationPressure, Ui.ORANGE,
                s.liquidationPressure >= 0 ? "SHORT LIQ BASKIN" : "LONG LIQ BASKIN",
                "L " + money(s.longLiquidations) + "  /  S " + money(s.shortLiquidations));
    }

    private void drawPressure(Canvas c, MarketState.Snapshot s, RectF r) {
        text(c, "MARKET PRESSURE", r.left + dp(12), r.top + dp(18), dp(10), Ui.MUTED, Paint.Align.LEFT, true);
        String direction = s.compositePressure > 8 ? "BUY PRESSURE" : (s.compositePressure < -8 ? "SELL PRESSURE" : "NEUTRAL");
        text(c, direction, r.right - dp(12), r.top + dp(18), dp(10), Ui.TEXT, Paint.Align.RIGHT, true);
        text(c, String.format(Locale.US, "%+.0f", s.compositePressure), r.left + dp(12), r.top + dp(56),
                dp(31), Ui.TEXT, Paint.Align.LEFT, true);

        float x1 = r.left + dp(88);
        float x2 = r.right - dp(12);
        float y = r.top + dp(53);
        p.setColor(Color.rgb(34, 43, 54));
        c.drawRoundRect(new RectF(x1, y - dp(4), x2, y + dp(4)), dp(4), dp(4), p);
        float mid = (x1 + x2) / 2f;
        float pos = (float) (mid + (x2 - x1) * 0.5 * s.compositePressure / 100.0);
        int dirColor = s.compositePressure >= 0 ? Ui.GREEN : Ui.RED;
        p.setColor(withAlpha(dirColor, 210));
        if (pos >= mid) c.drawRoundRect(new RectF(mid, y - dp(4), pos, y + dp(4)), dp(4), dp(4), p);
        else c.drawRoundRect(new RectF(pos, y - dp(4), mid, y + dp(4)), dp(4), dp(4), p);
        p.setColor(Ui.TEXT);
        c.drawCircle(pos, y, dp(5), p);

        text(c, "−100 SELL", x1, r.bottom - dp(10), dp(8), Ui.MUTED, Paint.Align.LEFT, false);
        text(c, "+100 BUY", x2, r.bottom - dp(10), dp(8), Ui.MUTED, Paint.Align.RIGHT, false);
    }

    private void metricCard(Canvas c, RectF r, String title, double score, int color,
                            String direction, String secondary) {
        roundRect(c, r, Ui.PANEL, dp(10));
        float abs = (float) Math.min(100, Math.abs(score));
        int accent = withAlpha(color, 110 + (int) (abs * 1.2f));
        p.setColor(accent);
        c.drawRoundRect(new RectF(r.left, r.top, r.left + dp(3), r.bottom), dp(2), dp(2), p);

        text(c, title, r.left + dp(11), r.top + dp(16), dp(9), Ui.MUTED, Paint.Align.LEFT, true);
        text(c, String.format(Locale.US, "%+.0f", score), r.right - dp(11), r.top + dp(18), dp(15), color, Paint.Align.RIGHT, true);
        text(c, direction, r.left + dp(11), r.centerY() + dp(2), dp(10), Ui.TEXT, Paint.Align.LEFT, true);
        text(c, secondary, r.left + dp(11), r.bottom - dp(8), dp(8), Ui.MUTED, Paint.Align.LEFT, false);

        float bx1 = r.left + r.width() * 0.55f;
        float bx2 = r.right - dp(11);
        float by = r.centerY() + dp(1);
        float mid = (bx1 + bx2) / 2f;
        p.setColor(Color.rgb(31, 40, 50));
        c.drawRoundRect(new RectF(bx1, by - dp(3), bx2, by + dp(3)), dp(3), dp(3), p);
        float end = (float) (mid + (bx2 - bx1) * 0.5 * clamp(score, -100, 100) / 100.0);
        p.setColor(accent);
        if (end >= mid) c.drawRoundRect(new RectF(mid, by - dp(3), end, by + dp(3)), dp(3), dp(3), p);
        else c.drawRoundRect(new RectF(end, by - dp(3), mid, by + dp(3)), dp(3), dp(3), p);
    }

    private RectF rect(float left, float top, float right, float height) {
        return new RectF(left, top, right, top + height);
    }

    private float yFor(double price, RectF plot, double min, double max) {
        if (max <= min) return plot.centerY();
        double f = (max - price) / (max - min);
        return (float) (plot.top + plot.height() * f);
    }

    private void roundRect(Canvas c, RectF r, int color, float radius) {
        p.setStyle(Paint.Style.FILL);
        p.setColor(color);
        c.drawRoundRect(r, radius, radius, p);
    }

    private void text(Canvas c, String value, float x, float y, float sizePx, int color,
                      Paint.Align align, boolean bold) {
        p.setStyle(Paint.Style.FILL);
        p.setTextAlign(align);
        p.setTextSize(sizePx);
        p.setColor(color);
        p.setTypeface(Typeface.create(Typeface.SANS_SERIF, bold ? Typeface.BOLD : Typeface.NORMAL));
        c.drawText(value == null ? "" : value, x, y, p);
    }

    private int withAlpha(int color, int alpha) {
        return Color.argb(Math.max(0, Math.min(255, alpha)), Color.red(color), Color.green(color), Color.blue(color));
    }

    private String formatPrice(double v) {
        if (v <= 0 || Double.isNaN(v)) return "—";
        if (v >= 1000) return String.format(Locale.US, "%,.2f", v);
        if (v >= 1) return String.format(Locale.US, "%.4f", v);
        if (v >= 0.01) return String.format(Locale.US, "%.5f", v);
        return String.format(Locale.US, "%.7f", v);
    }

    private String money(double v) {
        double a = Math.abs(v);
        String s;
        if (a >= 1_000_000_000) s = String.format(Locale.US, "$%.2fB", a / 1_000_000_000.0);
        else if (a >= 1_000_000) s = String.format(Locale.US, "$%.2fM", a / 1_000_000.0);
        else if (a >= 1_000) s = String.format(Locale.US, "$%.1fK", a / 1_000.0);
        else s = String.format(Locale.US, "$%.0f", a);
        return s;
    }

    private String signedMoney(double v) {
        return (v >= 0 ? "+" : "−") + money(v);
    }

    private String formatPercent(double v, int decimals) {
        if (Double.isNaN(v) || Double.isInfinite(v)) return "—";
        return String.format(Locale.US, "%+." + decimals + "f%%", v);
    }

    private String windowLabel() {
        return windowLabels[selectedWindow];
    }

    private float dp(float d) {
        return Ui.dp(getContext(), d);
    }

    private static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }

    @Override
    public boolean onTouchEvent(MotionEvent event) {
        if (event.getAction() != MotionEvent.ACTION_UP) return true;
        float x = event.getX();
        float y = event.getY();
        if (closeRect.contains(x, y)) {
            if (onClose != null) onClose.run();
            return true;
        }
        for (int i = 0; i < windowRects.size(); i++) {
            if (windowRects.get(i).contains(x, y)) {
                selectedWindow = i;
                invalidate();
                return true;
            }
        }
        return true;
    }
}
