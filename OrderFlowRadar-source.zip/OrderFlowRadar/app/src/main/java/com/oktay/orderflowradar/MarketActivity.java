package com.oktay.orderflowradar;

import android.app.Activity;
import android.content.pm.ActivityInfo;
import android.os.Bundle;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowInsetsController;

public class MarketActivity extends Activity {
    public static final String EXTRA_SYMBOL = "symbol";

    private BinanceMarketClient client;
    private MarketCanvasView marketView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setRequestedOrientation(ActivityInfo.SCREEN_ORIENTATION_SENSOR_LANDSCAPE);
        getWindow().setStatusBarColor(Ui.BG);
        getWindow().setNavigationBarColor(Ui.BG);
        hideSystemUi();

        String symbol = CoinStore.normalize(getIntent().getStringExtra(EXTRA_SYMBOL));
        if (symbol.isEmpty()) symbol = "BTCUSDT";

        MarketState state = new MarketState(symbol);
        marketView = new MarketCanvasView(this, state);
        marketView.setOnClose(this::finish);
        setContentView(marketView);

        client = new BinanceMarketClient(symbol, state, () -> {
            if (marketView != null) marketView.postInvalidateOnAnimation();
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        hideSystemUi();
        if (client != null) client.start();
    }

    @Override
    protected void onPause() {
        if (client != null) client.stop();
        super.onPause();
    }

    private void hideSystemUi() {
        if (android.os.Build.VERSION.SDK_INT >= 30) {
            WindowInsetsController controller = getWindow().getInsetsController();
            if (controller != null) {
                controller.hide(WindowInsets.Type.statusBars() | WindowInsets.Type.navigationBars());
                controller.setSystemBarsBehavior(
                        WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
            }
        } else {
            getWindow().getDecorView().setSystemUiVisibility(
                    android.view.View.SYSTEM_UI_FLAG_FULLSCREEN |
                    android.view.View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
                    android.view.View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
                    android.view.View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
        }
    }
}
