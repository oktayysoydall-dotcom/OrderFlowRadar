package com.oktay.orderflowradar;

import android.content.Context;
import android.content.SharedPreferences;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.LinkedHashSet;
import java.util.List;
import java.util.Locale;
import java.util.Set;

final class CoinStore {
    private static final String PREFS = "order_flow_radar";
    private static final String KEY = "symbols";
    private static final List<String> DEFAULTS = Arrays.asList(
            "BTCUSDT", "ETHUSDT", "SOLUSDT", "XRPUSDT"
    );

    private CoinStore() {}

    static List<String> load(Context context) {
        SharedPreferences p = context.getSharedPreferences(PREFS, Context.MODE_PRIVATE);
        Set<String> stored = p.getStringSet(KEY, null);
        if (stored == null) return new ArrayList<>(DEFAULTS);
        List<String> out = new ArrayList<>(stored);
        out.sort(String::compareTo);
        return out;
    }

    static void add(Context context, String raw) {
        String symbol = normalize(raw);
        if (symbol.isEmpty()) return;
        LinkedHashSet<String> set = new LinkedHashSet<>(load(context));
        set.add(symbol);
        save(context, set);
    }

    static void remove(Context context, String symbol) {
        LinkedHashSet<String> set = new LinkedHashSet<>(load(context));
        set.remove(symbol);
        save(context, set);
    }

    static String normalize(String raw) {
        if (raw == null) return "";
        String s = raw.toUpperCase(Locale.US)
                .replace("/", "")
                .replace("-", "")
                .replace("_", "")
                .replace(" ", "")
                .trim();
        if (s.isEmpty()) return "";
        if (!s.matches("[A-Z0-9]{2,20}")) return "";
        if (!s.endsWith("USDT")) s += "USDT";
        return s;
    }

    private static void save(Context context, Set<String> set) {
        context.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
                .edit()
                .putStringSet(KEY, new LinkedHashSet<>(set))
                .apply();
    }
}
