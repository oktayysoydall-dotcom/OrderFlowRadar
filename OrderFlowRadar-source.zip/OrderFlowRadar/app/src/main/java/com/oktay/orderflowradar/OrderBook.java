package com.oktay.orderflowradar;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;

final class OrderBook {
    enum Result { APPLIED, IGNORED, GAP }

    static final class ApplyResult {
        final Result result;
        final double pressureNotional;
        final double changedNotional;

        ApplyResult(Result result, double pressureNotional, double changedNotional) {
            this.result = result;
            this.pressureNotional = pressureNotional;
            this.changedNotional = changedNotional;
        }
    }

    static final class Wall {
        final boolean bid;
        final double price;
        final double notional;

        Wall(boolean bid, double price, double notional) {
            this.bid = bid;
            this.price = price;
            this.notional = notional;
        }
    }

    private final TreeMap<Double, Double> bids = new TreeMap<>(Collections.reverseOrder());
    private final TreeMap<Double, Double> asks = new TreeMap<>();
    private long lastUpdateId = -1;
    private boolean firstAfterSnapshot = true;

    synchronized void reset() {
        bids.clear();
        asks.clear();
        lastUpdateId = -1;
        firstAfterSnapshot = true;
    }

    synchronized void setSnapshot(long updateId, JSONArray bidRows, JSONArray askRows) {
        bids.clear();
        asks.clear();
        loadRows(bids, bidRows);
        loadRows(asks, askRows);
        lastUpdateId = updateId;
        firstAfterSnapshot = true;
        trim();
    }

    private void loadRows(TreeMap<Double, Double> map, JSONArray rows) {
        for (int i = 0; i < rows.length(); i++) {
            JSONArray row = rows.optJSONArray(i);
            if (row == null || row.length() < 2) continue;
            double p = row.optDouble(0, 0);
            double q = row.optDouble(1, 0);
            if (p > 0 && q > 0) map.put(p, q);
        }
    }

    synchronized long getLastUpdateId() {
        return lastUpdateId;
    }

    synchronized ApplyResult applyDepth(JSONObject event) {
        long u = event.optLong("u", -1);
        long U = event.optLong("U", -1);
        long pu = event.optLong("pu", -1);
        if (u < 0 || U < 0 || lastUpdateId < 0) {
            return new ApplyResult(Result.GAP, 0, 0);
        }
        if (u <= lastUpdateId) {
            return new ApplyResult(Result.IGNORED, 0, 0);
        }

        if (firstAfterSnapshot) {
            if (U > lastUpdateId + 1 || u < lastUpdateId) {
                return new ApplyResult(Result.GAP, 0, 0);
            }
        } else {
            boolean puMismatch = pu >= 0 && pu != lastUpdateId;
            boolean idGap = pu < 0 && U > lastUpdateId + 1;
            if (puMismatch || idGap) {
                return new ApplyResult(Result.GAP, 0, 0);
            }
        }

        double pressure = 0;
        double changed = 0;
        double referenceMid = mid();
        Flow f1 = applyRows(bids, event.optJSONArray("b"), true, referenceMid);
        Flow f2 = applyRows(asks, event.optJSONArray("a"), false, referenceMid);
        pressure += f1.pressure + f2.pressure;
        changed += f1.changed + f2.changed;
        lastUpdateId = u;
        firstAfterSnapshot = false;
        trim();
        return new ApplyResult(Result.APPLIED, pressure, changed);
    }

    private static final class Flow {
        double pressure;
        double changed;
    }

    private Flow applyRows(TreeMap<Double, Double> map, JSONArray rows, boolean bid, double referenceMid) {
        Flow out = new Flow();
        if (rows == null) return out;
        for (int i = 0; i < rows.length(); i++) {
            JSONArray row = rows.optJSONArray(i);
            if (row == null || row.length() < 2) continue;
            double p = row.optDouble(0, 0);
            double q = row.optDouble(1, 0);
            if (p <= 0) continue;
            Double oldObj = map.get(p);
            double old = oldObj == null ? 0 : oldObj;
            double delta = q - old;
            double n = Math.abs(delta) * p;
            double weight = distanceWeight(p, referenceMid);
            if (n > 0 && weight > 0) {
                // Bullish: bid liquidity is added OR ask liquidity is removed.
                // Bearish: bid liquidity is removed OR ask liquidity is added.
                // Only the nearest ±1% contributes, with proximity weighting.
                double signed = bid ? delta * p : -delta * p;
                out.pressure += signed * weight;
                out.changed += n * weight;
            }
            if (q <= 0) map.remove(p);
            else map.put(p, q);
        }
        return out;
    }

    synchronized double bestBid() {
        return bids.isEmpty() ? 0 : bids.firstKey();
    }

    synchronized double bestAsk() {
        return asks.isEmpty() ? 0 : asks.firstKey();
    }

    synchronized double mid() {
        double b = bestBid();
        double a = bestAsk();
        if (b > 0 && a > 0) return (b + a) / 2.0;
        return Math.max(b, a);
    }

    synchronized double weightedImbalance() {
        double m = mid();
        if (m <= 0) return 0;
        double bidN = weightedNotional(bids, m, true);
        double askN = weightedNotional(asks, m, false);
        double total = bidN + askN;
        if (total <= 0) return 0;
        return clamp(100.0 * (bidN - askN) / total, -100, 100);
    }

    private double weightedNotional(TreeMap<Double, Double> map, double mid, boolean bid) {
        double sum = 0;
        for (Map.Entry<Double, Double> e : map.entrySet()) {
            double p = e.getKey();
            double distance = Math.abs(p - mid) / mid;
            if (distance > 0.01) break;
            double w = distanceWeight(p, mid);
            sum += p * e.getValue() * w;
        }
        return sum;
    }

    private double distanceWeight(double price, double mid) {
        if (mid <= 0 || price <= 0) return 0;
        double distance = Math.abs(price - mid) / mid;
        if (distance > 0.01) return 0;
        if (distance <= 0.001) return 1.0;
        if (distance <= 0.0025) return 0.80;
        if (distance <= 0.005) return 0.50;
        return 0.25;
    }

    synchronized List<Wall> walls(double aroundPct, int maxCount) {
        double m = mid();
        if (m <= 0) return new ArrayList<>();
        List<Wall> all = new ArrayList<>();
        collectWalls(all, bids, true, m, aroundPct);
        collectWalls(all, asks, false, m, aroundPct);
        all.sort((a, b) -> Double.compare(b.notional, a.notional));
        if (all.size() > maxCount) return new ArrayList<>(all.subList(0, maxCount));
        return all;
    }

    private void collectWalls(List<Wall> out, TreeMap<Double, Double> map, boolean bid,
                              double mid, double aroundPct) {
        for (Map.Entry<Double, Double> e : map.entrySet()) {
            double p = e.getKey();
            if (Math.abs(p - mid) / mid > aroundPct) break;
            out.add(new Wall(bid, p, p * e.getValue()));
        }
    }

    private void trim() {
        while (bids.size() > 1800) bids.pollLastEntry();
        while (asks.size() > 1800) asks.pollLastEntry();
    }

    private static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }
}
