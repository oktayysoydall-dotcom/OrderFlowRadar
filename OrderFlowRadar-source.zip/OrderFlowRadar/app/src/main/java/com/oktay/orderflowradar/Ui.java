package com.oktay.orderflowradar;

import android.content.Context;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.util.TypedValue;
import android.view.View;
import android.widget.TextView;

final class Ui {
    static final int BG = Color.rgb(5, 8, 13);
    static final int PANEL = Color.rgb(12, 18, 27);
    static final int PANEL_2 = Color.rgb(17, 25, 36);
    static final int BORDER = Color.rgb(38, 51, 66);
    static final int TEXT = Color.rgb(234, 241, 247);
    static final int MUTED = Color.rgb(135, 151, 166);
    static final int CYAN = Color.rgb(87, 217, 255);
    static final int GREEN = Color.rgb(65, 214, 147);
    static final int RED = Color.rgb(255, 92, 112);
    static final int BLUE = Color.rgb(71, 147, 255);
    static final int PURPLE = Color.rgb(169, 119, 255);
    static final int AMBER = Color.rgb(255, 190, 82);
    static final int ORANGE = Color.rgb(255, 137, 76);

    private Ui() {}

    static int dp(Context c, float value) {
        return Math.round(TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_DIP, value, c.getResources().getDisplayMetrics()));
    }

    static float sp(Context c, float value) {
        return TypedValue.applyDimension(
                TypedValue.COMPLEX_UNIT_SP, value, c.getResources().getDisplayMetrics());
    }

    static GradientDrawable rounded(int color, float radiusDp, Context c) {
        GradientDrawable d = new GradientDrawable();
        d.setColor(color);
        d.setCornerRadius(dp(c, radiusDp));
        return d;
    }

    static GradientDrawable roundedStroke(int color, int strokeColor, float radiusDp, Context c) {
        GradientDrawable d = rounded(color, radiusDp, c);
        d.setStroke(dp(c, 1), strokeColor);
        return d;
    }

    static void styleText(TextView v, float sp, int color, boolean bold) {
        v.setTextSize(TypedValue.COMPLEX_UNIT_SP, sp);
        v.setTextColor(color);
        if (bold) v.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
    }

    static void pad(View v, Context c, int l, int t, int r, int b) {
        v.setPadding(dp(c, l), dp(c, t), dp(c, r), dp(c, b));
    }
}
