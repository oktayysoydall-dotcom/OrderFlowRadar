package com.oktay.orderflowradar;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;
import java.util.List;

final class MarketState {
    static final class Candle {
        long openTime;
        double open, high, low, close, volume;
        boolean closed;

        Candle(long openTime, double open, double high, double low, double close,
               double volume, boolean closed) {
            this.openTime = openTime;
            this.open = open;
            this.high = high;
            this.low = low;
            this.close = close;
            this.volume = volume;
            this.closed = closed;
        }

        Candle copy() {
            return new Candle(openTime, open, high, low, close, volume, closed);
        }
    }

    static final class TradeTick {
        final long time;
        final double price;
        final double signedNotional;
        final double absoluteNotional;

        TradeTick(long time, double price, double signedNotional, double absoluteNotional) {
            this.time = time;
            this.price = price;
            this.signedNotional = signedNotional;
            this.absoluteNotional = absoluteNotional;
        }
    }

    static final class FlowTick {
        final long time;
        final double pressure;
        final double absolute;

        FlowTick(long time, double pressure, double absolute) {
            this.time = time;
            this.pressure = pressure;
            this.absolute = absolute;
        }
    }

    static final class LiqTick {
        final long time;
        final boolean longLiquidation;
        final double notional;

        LiqTick(long time, boolean longLiquidation, double notional) {
            this.time = time;
            this.longLiquidation = longLiquidation;
            this.notional = notional;
        }
    }

    static final class Snapshot {
        final String symbol;
        final List<Candle> candles;
        final List<OrderBook.Wall> walls;
        final double lastPrice;
        final double markPrice;
        final double fundingRate;
        final double bookImbalance;
        final double deltaRatio;
        final double deltaNotional;
        final double cvdNotional;
        final double cvdRatio;
        final double absorption;
        final double liquidityFlow;
        final double longLiquidations;
        final double shortLiquidations;
        final double liquidationPressure;
        final double compositePressure;
        final double priceChangeBps;
        final long windowMs;
        final boolean bookReady;
        final String status;
        final String error;
        final long lastEventAt;

        Snapshot(String symbol, List<Candle> candles, List<OrderBook.Wall> walls,
                 double lastPrice, double markPrice, double fundingRate,
                 double bookImbalance, double deltaRatio, double deltaNotional,
                 double cvdNotional, double cvdRatio, double absorption,
                 double liquidityFlow, double longLiquidations, double shortLiquidations,
                 double liquidationPressure, double compositePressure,
                 double priceChangeBps, long windowMs, boolean bookReady,
                 String status, String error, long lastEventAt) {
            this.symbol = symbol;
            this.candles = candles;
            this.walls = walls;
            this.lastPrice = lastPrice;
            this.markPrice = markPrice;
            this.fundingRate = fundingRate;
            this.bookImbalance = bookImbalance;
            this.deltaRatio = deltaRatio;
            this.deltaNotional = deltaNotional;
            this.cvdNotional = cvdNotional;
            this.cvdRatio = cvdRatio;
            this.absorption = absorption;
            this.liquidityFlow = liquidityFlow;
            this.longLiquidations = longLiquidations;
            this.shortLiquidations = shortLiquidations;
            this.liquidationPressure = liquidationPressure;
            this.compositePressure = compositePressure;
            this.priceChangeBps = priceChangeBps;
            this.windowMs = windowMs;
            this.bookReady = bookReady;
            this.status = status;
            this.error = error;
            this.lastEventAt = lastEventAt;
        }
    }

    final OrderBook orderBook = new OrderBook();
    private final String symbol;
    private final List<Candle> candles = new ArrayList<>();
    private final Deque<TradeTick> trades = new ArrayDeque<>();
    private final Deque<FlowTick> flows = new ArrayDeque<>();
    private final Deque<LiqTick> liquidations = new ArrayDeque<>();

    private double lastPrice;
    private double markPrice;
    private double fundingRate;
    private boolean bookReady;
    private String status = "BAĞLANIYOR";
    private String error = "";
    private long lastEventAt;

    MarketState(String symbol) {
        this.symbol = symbol;
    }

    synchronized void setStatus(String status) {
        this.status = status;
        this.lastEventAt = System.currentTimeMillis();
    }

    synchronized void setError(String error) {
        this.error = error == null ? "" : error;
        this.status = "HATA";
        this.lastEventAt = System.currentTimeMillis();
    }

    synchronized void clearError() {
        this.error = "";
    }

    synchronized void setBookReady(boolean ready) {
        this.bookReady = ready;
        if (ready) this.status = "CANLI";
        this.lastEventAt = System.currentTimeMillis();
    }

    synchronized void seedCandles(List<Candle> seed) {
        candles.clear();
        candles.addAll(seed);
        trimCandles();
        if (!candles.isEmpty()) lastPrice = candles.get(candles.size() - 1).close;
        lastEventAt = System.currentTimeMillis();
    }

    synchronized void updateCandle(Candle c) {
        if (candles.isEmpty()) {
            candles.add(c);
        } else {
            Candle last = candles.get(candles.size() - 1);
            if (last.openTime == c.openTime) candles.set(candles.size() - 1, c);
            else if (c.openTime > last.openTime) candles.add(c);
        }
        lastPrice = c.close;
        trimCandles();
        touch();
    }

    synchronized void addTrade(long time, double price, double qty, boolean buyerMaker) {
        if (price <= 0 || qty <= 0) return;
        double n = price * qty;
        double signed = buyerMaker ? -n : n;
        trades.addLast(new TradeTick(time, price, signed, n));
        lastPrice = price;
        prune(time);
        touch();
    }

    synchronized void addBookFlow(long time, double pressure, double changed) {
        if (changed <= 0) return;
        flows.addLast(new FlowTick(time, pressure, changed));
        prune(time);
        touch();
    }

    synchronized void addLiquidation(long time, boolean longLiq, double notional) {
        if (notional <= 0) return;
        liquidations.addLast(new LiqTick(time, longLiq, notional));
        prune(time);
        touch();
    }

    synchronized void updateMark(double mark, double funding) {
        if (mark > 0) markPrice = mark;
        fundingRate = funding;
        touch();
    }

    synchronized Snapshot snapshot(long windowMs) {
        long now = System.currentTimeMillis();
        prune(now);
        long cutoff = now - windowMs;

        double delta = 0;
        double volume = 0;
        double firstTradePrice = 0;
        double finalTradePrice = 0;
        for (TradeTick t : trades) {
            if (t.time < cutoff) continue;
            if (firstTradePrice == 0) firstTradePrice = t.price;
            finalTradePrice = t.price;
            delta += t.signedNotional;
            volume += t.absoluteNotional;
        }
        double deltaRatio = volume > 0 ? 100.0 * delta / volume : 0;
        double priceBps = firstTradePrice > 0 && finalTradePrice > 0
                ? 10000.0 * (finalTradePrice - firstTradePrice) / firstTradePrice : 0;

        // Rolling CVD uses up to five minutes so it carries more context than instantaneous delta.
        long cvdCutoff = now - Math.max(windowMs, 300_000L);
        double cvd = 0;
        double cvdVolume = 0;
        for (TradeTick t : trades) {
            if (t.time < cvdCutoff) continue;
            cvd += t.signedNotional;
            cvdVolume += t.absoluteNotional;
        }
        double cvdRatio = cvdVolume > 0 ? 100.0 * cvd / cvdVolume : 0;

        double flowPressure = 0;
        double flowAbs = 0;
        for (FlowTick f : flows) {
            if (f.time < cutoff) continue;
            flowPressure += f.pressure;
            flowAbs += f.absolute;
        }
        double flowRatio = flowAbs > 0 ? 100.0 * flowPressure / flowAbs : 0;

        double longLiq = 0;
        double shortLiq = 0;
        for (LiqTick l : liquidations) {
            if (l.time < cutoff) continue;
            if (l.longLiquidation) longLiq += l.notional;
            else shortLiq += l.notional;
        }
        double liqPressure = longLiq + shortLiq > 0
                ? 100.0 * (shortLiq - longLiq) / (shortLiq + longLiq) : 0;

        double book = orderBook.weightedImbalance();
        double absorption = absorptionScore(deltaRatio, priceBps, volume);
        double composite = clamp(
                0.30 * book +
                0.25 * deltaRatio +
                0.12 * cvdRatio +
                0.18 * flowRatio +
                0.10 * absorption +
                0.05 * liqPressure,
                -100, 100);

        List<Candle> candleCopies = new ArrayList<>();
        int start = Math.max(0, candles.size() - 90);
        for (int i = start; i < candles.size(); i++) candleCopies.add(candles.get(i).copy());
        List<OrderBook.Wall> walls = orderBook.walls(0.0125, 30);

        return new Snapshot(symbol, candleCopies, walls, lastPrice, markPrice, fundingRate,
                book, deltaRatio, delta, cvd, cvdRatio, absorption, flowRatio,
                longLiq, shortLiq, liqPressure, composite, priceBps, windowMs,
                bookReady, status, error, lastEventAt);
    }

    private double absorptionScore(double deltaRatio, double priceBps, double volume) {
        if (volume < 1_000 || Math.abs(deltaRatio) < 18) return 0;
        // Strong taker flow that fails to move price is interpreted as opposing absorption.
        double inefficiency = 1.0 - Math.min(1.0, Math.abs(priceBps) / 8.0);
        if (inefficiency <= 0) return 0;
        double strength = Math.min(100, Math.abs(deltaRatio) * 1.35) * inefficiency;
        if (deltaRatio > 0 && priceBps < 6) return -strength;  // buys absorbed -> sell absorption
        if (deltaRatio < 0 && priceBps > -6) return strength; // sells absorbed -> buy absorption
        return 0;
    }

    private void trimCandles() {
        while (candles.size() > 150) candles.remove(0);
    }

    private void prune(long now) {
        long cutoff = now - 360_000L;
        while (!trades.isEmpty() && trades.peekFirst().time < cutoff) trades.removeFirst();
        while (!flows.isEmpty() && flows.peekFirst().time < cutoff) flows.removeFirst();
        while (!liquidations.isEmpty() && liquidations.peekFirst().time < cutoff) liquidations.removeFirst();
    }

    private void touch() {
        lastEventAt = System.currentTimeMillis();
        if (bookReady && !"HATA".equals(status)) status = "CANLI";
    }

    private static double clamp(double v, double min, double max) {
        return Math.max(min, Math.min(max, v));
    }
}
