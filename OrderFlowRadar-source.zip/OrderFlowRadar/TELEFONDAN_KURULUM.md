# Sadece telefonla APK üretme ve kurma

Bu proje bilgisayar gerektirmeden GitHub Actions üzerinde APK olarak derlenebilir.

## 1. GitHub hesabına giriş yap

Telefonda tarayıcıdan GitHub'a giriş yap. Hesabın yoksa ücretsiz hesap oluştur.

## 2. Yeni depo (repository) oluştur

GitHub'da **New repository** seç.

- Repository name: `OrderFlowRadar`
- Public veya Private seçebilirsin.
- **Create repository** düğmesine bas.

## 3. Bu ZIP'in içindeki proje dosyalarını GitHub'a yükle

GitHub deposunda **Add file > Upload files** seçeneğini kullan.

ZIP dosyasını doğrudan repository'ye tek dosya olarak koyma. ZIP'i telefonda Dosyalar / ZArchiver benzeri bir uygulamayla çıkart ve `OrderFlowRadar` klasörünün **içindeki dosya ve klasörleri** repository'nin köküne yükle.

Repository'nin kökünde şunları görmelisin:

- `.github`
- `app`
- `build.gradle`
- `settings.gradle`
- `gradle.properties`

`.github/workflows/build-apk.yml` dosyasının GitHub'da bulunduğunu kontrol et.

## 4. APK derlemesini çalıştır

Repository sayfasında:

1. **Actions** sekmesine gir.
2. Solda **Build Android APK** workflow'unu seç.
3. **Run workflow** düğmesine bas.
4. `main` veya kullandığın varsayılan branch seçiliyken tekrar **Run workflow** de.

Dosyaları ilk kez `main` branch'ine yüklediğinde workflow otomatik de başlayabilir.

## 5. APK'yı indir

Derleme başarıyla tamamlanınca workflow çalışmasını aç.

Sayfanın altındaki **Artifacts** bölümünde:

`OrderFlowRadar-debug-apk`

isimli dosyaya dokun. GitHub bunu ZIP olarak indirir.

ZIP'i aç ve içindeki:

`app-debug.apk`

dosyasını çıkar.

## 6. Android telefona kur

`app-debug.apk` dosyasına dokun.

Android izin isterse kullandığın tarayıcı veya dosya yöneticisi için **Bilinmeyen uygulamaları yükle / Bu kaynaktan izin ver** seçeneğini etkinleştir.

Sonra **Yükle** düğmesine bas.

## Güncelleme yapmak

Projede değişiklik yaptığında GitHub'a yeni dosyaları gönder. Actions tekrar APK üretir. Aynı `applicationId` kullanıldığı sürece yeni APK eski uygulamanın üzerine kurulabilir.

## Güvenlik notu

Bu sürüm Binance public market verisini kullanır. Binance API key veya secret key istemez ve emir açıp kapatmaz.
